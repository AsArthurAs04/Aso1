#!/bin/bash

dconf write /org/ayatana/indicator/session/user-show-menu false

